import numpy as np
import pandas as pd

idades = np.array([18, 21, 19, 22, 20])
print("1. Vetor de idades:", idades)

matriz = np.array([
    [1, 2, 3],
    [4, 5, 6]
])
print("2. Shape da matriz:", matriz.shape)
print("   Elemento [1, 2]:", matriz[1, 2])

idades_serie = pd.Series(
    [18, 21, 19, 22, 20],
    index=["Ana", "Bruno", "Carla", "Diego", "Eva"],
    name="idades"
)
print("\n3. Series de idades:\n", idades_serie)

print("\n4. Idade da Carla (loc):", idades_serie.loc["Carla"])

print("\n5. Pessoas com 21 anos ou mais:\n", idades_serie[idades_serie >= 21])